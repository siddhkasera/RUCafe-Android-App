package com.example.rucafe;

/**
 * This is an interface that defines two methods
 * @author Siddhi Kasera and Sonal Madhok
 */
public interface Customizable{
    boolean add(Object obj);
    boolean remove(Object obj);
}